import React, { useState } from "react";
import { Text, TextInput, TouchableOpacity, ActivityIndicator, Image, Alert, KeyboardAvoidingView, Platform, ScrollView } from "react-native";
import { useRouter } from "expo-router";
import { useDispatch } from "react-redux";
import { setWalletData } from "../store/wallet.slice";
import { api } from "../services/api";
import * as ImagePicker from "expo-image-picker";

export default function Register() {
  const router = useRouter();
  const dispatch = useDispatch();

  const [name, setName] = useState("");
  const [email, setEmail] = useState("");
  const [passport, setPassport] = useState<string | null>(null);
  const [selfie, setSelfie] = useState<string | null>(null);
  const [loading, setLoading] = useState(false);

  /* ---------------- Image Picker ---------------- */

  const pickImage = async (setImage: (uri: string) => void) => {
    const permission = await ImagePicker.requestMediaLibraryPermissionsAsync();

    if (!permission.granted) {
      Alert.alert("Permission required", "We need access to your gallery");
      return;
    }

    const result = await ImagePicker.launchImageLibraryAsync({
      mediaTypes: ImagePicker.MediaTypeOptions.Images,
      quality: 0.7,
      base64: true,
    });

    if (!result.canceled && result.assets?.length) {
      setImage(result.assets[0].uri);
    }
  };

  /* ---------------- Validation ---------------- */

  const validate = () => {
    if (!name.trim()) return "Name is required";
    if (!email.includes("@")) return "Invalid email";
    if (!passport || !selfie) return "Please upload passport and selfie";
    return null;
  };

  /* ---------------- Register ---------------- */

  const handleRegister = async () => {
    const validationError = validate();
    if (validationError) {
      Alert.alert("Validation Error", validationError);
      return;
    }

    try {
      setLoading(true);

      const res = await api.post("/register", {
        name,
        email,
        passportImage: passport,
        selfieImage: selfie,
      });

      dispatch(setWalletData(res.data));

      router.replace("/wallet"); // better than push
    } catch (err: any) {
      const message = err?.response?.data?.message || err?.message || "Something went wrong";

      Alert.alert("Registration Failed", message);
    } finally {
      setLoading(false);
    }
  };

  /* ---------------- UI ---------------- */

  return (
    <KeyboardAvoidingView behavior={Platform.OS === "ios" ? "padding" : undefined} className="flex-1">
      <ScrollView contentContainerStyle={{ flexGrow: 1 }} className="bg-white p-6 justify-center">
        <Text className="text-2xl font-bold mb-6 text-center">Register Identity</Text>

        <TextInput placeholder="Name" value={name} onChangeText={setName} className="border border-gray-300 rounded-xl p-4 mb-4" />

        <TextInput placeholder="Email" value={email} onChangeText={setEmail} keyboardType="email-address" autoCapitalize="none" className="border border-gray-300 rounded-xl p-4 mb-4" />

        {/* Passport */}
        <TouchableOpacity className="bg-blue-600 p-4 rounded-xl mb-3" onPress={() => pickImage(setPassport)}>
          <Text className="text-white text-center">Upload Passport</Text>
        </TouchableOpacity>

        {passport && <Image source={{ uri: passport }} className="h-24 w-24 mb-4 self-center rounded-lg" />}

        {/* Selfie */}
        <TouchableOpacity className="bg-green-600 p-4 rounded-xl mb-3" onPress={() => pickImage(setSelfie)}>
          <Text className="text-white text-center">Upload Selfie</Text>
        </TouchableOpacity>

        {selfie && <Image source={{ uri: selfie }} className="h-24 w-24 mb-4 self-center rounded-lg" />}

        <TouchableOpacity className={`p-4 rounded-xl ${loading ? "bg-gray-400" : "bg-black"}`} onPress={handleRegister} disabled={loading}>
          {loading ? <ActivityIndicator color="white" /> : <Text className="text-white text-center font-semibold">Register</Text>}
        </TouchableOpacity>
      </ScrollView>
    </KeyboardAvoidingView>
  );
}
